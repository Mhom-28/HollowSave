# HOLLOW SAVE (Fabric 1.20.1) - มอดสยองขวัญแนว ARG

ต้องใช้: Minecraft Java 1.20.1 + Fabric Loader 0.15.x + Fabric API 0.92.2+1.20.1 (ลงใน mods)
ห้ามเล่นโหมด Peaceful (ผีกับบอสจะหายไป) ควรเล่น Easy ขึ้นไป และเล่น Windows เป็นหลัก

## วิธีทำเป็น .jar (เลือกอย่างใดอย่างหนึ่ง)

### A) ผ่าน GitHub (ทำจากมือถือได้ ไม่ต้องลงอะไร)
1. สร้าง repo ใหม่ใน GitHub แล้วอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ (รวม .github)
2. ไปที่แท็บ Actions รอ workflow "build" รันเสร็จ (ประมาณ 3-5 นาที)
3. เข้าไปในรอบที่รัน กดดาวน์โหลด artifact "hollowsave-jar" จะได้ hollowsave-1.0.0.jar

### B) บิลด์บนคอม
1. ติดตั้ง JDK 17 และ Gradle 8.7
2. เปิดเทอร์มินัลในโฟลเดอร์นี้ แล้วรัน: gradle build
3. ไฟล์อยู่ที่ build/libs/hollowsave-1.0.0.jar (ไม่ใช่ตัว -sources)

ใส่ .jar ลงโฟลเดอร์ .minecraft/mods พร้อม Fabric API

## วิธีเล่น
- เล่นปกติ 5 นาทีแรก แล้วเรื่องจะเริ่ม ตัวเลขเวลาอยู่ใน StoryManager.java (T_STAGE1, T_STAGE2)
- ผี ECHO จะขยับเฉพาะตอนคุณไม่มอง ถ้าจ้องมันจะหยุดและหายไป
- ARG: อ่านไฟล์ READ_ME_13.txt บนเดสก์ท็อป ถอดรหัส Base64 แล้วพิมพ์ /hollow decode <คำที่ได้>
- ไปที่ศาลเจ้าตามพิกัด เพื่อเข้าฉากบอส THE ERASER

## คำสั่ง
- /hollow hint            ใบ้ตามด่าน
- /hollow decode <code>   ถอดรหัส ARG
- /hollow cleanup         ลบไฟล์ทั้งหมดที่มอดสร้างนอกเกม และคืนชื่อหน้าต่าง
- (OP) /hollow stage <0-5>, /hollow scare <FACE|ECHO>, /hollow fx <type> [arg], /hollow reset
  ตัวอย่าง fx: GLITCH, LAG, FAKE_LOADING, FAKE_ERROR CRASH, OS_ERROR title|msg, TITLE RANDOM, ICON GLITCH,
  SOUND SCREAM, FILE CLUE
- ข้ามไปบอสเพื่อทดสอบ: /hollow stage 2 แล้ว /hollow decode ARCHIVE13

## ความปลอดภัย
- ไม่ลบ ไม่แก้ไฟล์จริงของเครื่อง ไม่ส่งข้อมูลออกเน็ต สร้างแค่ไฟล์ข้อความ/รูปบนเดสก์ท็อปและในโฟลเดอร์เกม
- ชื่อผู้ใช้เครื่องถูกอ่านแค่เพื่อใส่ในข้อความไฟล์ ไม่ได้ถูกส่งไปไหน
- ไอคอนหน้าต่างที่ถูกเปลี่ยนจะกลับเป็นปกติเมื่อเปิดเกมใหม่
- เสียงนอกเกมดังไม่เกินครึ่งหนึ่งของระดับสูงสุด แต่ควรลดเสียงลงก่อนเล่น (ปรับที่ VOL ใน ExternalAudio.java)
- ปิดการแปลงบล็อกในโลกได้ที่ WORLD_DAMAGE = false ใน StoryManager.java
- ฉากบอสสร้างที่ความสูง Y=200 ห่างจากศาลเจ้า 300 บล็อก ไม่แตะสิ่งก่อสร้างของคุณ
