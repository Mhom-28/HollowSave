package com.hollowsave;

import com.hollowsave.story.StoryManager;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HollowSave implements ModInitializer {
    public static final String ID = "hollowsave";
    public static final Logger LOG = LoggerFactory.getLogger(ID);

    @Override
    public void onInitialize() {
        ModEntities.init();
        StoryManager.init();
        LOG.info("[HOLLOW SAVE] 13 is awake.");
    }
}
