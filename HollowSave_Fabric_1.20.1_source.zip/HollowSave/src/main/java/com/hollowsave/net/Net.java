package com.hollowsave.net;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

/** One packet type: server tells the client which effect to run. */
public final class Net {
    public static final Identifier FX = new Identifier("hollowsave", "fx");

    public static void send(ServerPlayerEntity p, String type, String arg, int n) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeString(type);
        buf.writeString(arg);
        buf.writeInt(n);
        ServerPlayNetworking.send(p, FX, buf);
    }

    public static void send(ServerPlayerEntity p, String type) {
        send(p, type, "", 0);
    }

    private Net() {}
}
