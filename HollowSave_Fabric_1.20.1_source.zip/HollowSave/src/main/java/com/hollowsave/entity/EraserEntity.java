package com.hollowsave.entity;

import com.hollowsave.ModEntities;
import com.hollowsave.net.Net;
import com.hollowsave.story.StoryManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** THE ERASER - 3 phases. Erases the arena floor, teleports behind you, crashes your screen. */
public class EraserEntity extends HostileEntity {
    private static final String[] NAMES = {
            "▓▒░ THE ERASER ░▒▓", "THE ERASER", "T̷H̷E̷ ̷E̷R̷A̷S̷E̷R̷", "ERASER.exe", "§kTHE ERASER§r", "ผู้ลบ"};

    private final ServerBossBar bar = new ServerBossBar(Text.literal("THE ERASER"),
            BossBar.Color.RED, BossBar.Style.NOTCHED_10);
    private int phase = 1;
    private int arenaX, arenaY, arenaZ;
    private boolean arenaSet = false;

    public EraserEntity(EntityType<? extends EraserEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 500;
    }

    public static DefaultAttributeContainer.Builder attrs() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 400)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 14)
                .add(EntityAttributes.GENERIC_ARMOR, 8)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 80);
    }

    public void setArena(int x, int y, int z) {
        arenaX = x; arenaY = y; arenaZ = z; arenaSet = true;
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.0, true));
        this.goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 32f));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public boolean tryAttack(Entity target) {
        boolean ok = super.tryAttack(target);
        if (ok && target instanceof ServerPlayerEntity sp) Net.send(sp, "GLITCH", "", 25);
        return ok;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient) return;
        ServerWorld sw = (ServerWorld) this.getWorld();
        if (!arenaSet) setArena(getBlockX(), getBlockY() - 1, getBlockZ());

        bar.setPercent(getHealth() / getMaxHealth());
        float hp = getHealth() / getMaxHealth();
        int np = hp > 0.66f ? 1 : (hp > 0.33f ? 2 : 3);
        if (np != phase) { phase = np; phaseChange(sw); }
        if (age % 60 == 0) bar.setName(Text.literal(NAMES[random.nextInt(NAMES.length)]));

        LivingEntity tg = getTarget();
        if (tg instanceof ServerPlayerEntity sp) {
            if (age % 80 == 0) erase(sw, sp);
            if (phase >= 2 && age % 160 == 0) blink(sw, sp);
            if (phase >= 2 && age % 240 == 0) sp.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 120, 0));
            if (phase >= 2 && age % 300 == 0) Net.send(sp, "GLITCH", "", 40);
            if (phase >= 2 && age % 700 == 0) Net.send(sp, "LAG", "", 800);
            if (phase == 3 && age % 500 == 0) summonEcho(sw, sp);
        }
    }

    private boolean inArena(BlockPos p) {
        int dx = p.getX() - arenaX, dz = p.getZ() - arenaZ;
        return p.getY() == arenaY && dx * dx + dz * dz <= 21 * 21;
    }

    /** Telegraph, delete a patch of floor under the player, then restore it (glitch). */
    private void erase(ServerWorld sw, ServerPlayerEntity tg) {
        final BlockPos c = tg.getBlockPos().down();
        final int r = phase == 3 ? 2 : 1;
        sw.spawnParticles(ParticleTypes.REVERSE_PORTAL, c.getX() + 0.5, c.getY() + 1.2, c.getZ() + 0.5, 40, r, 0.1, r, 0.4);
        this.playSound(SoundEvents.BLOCK_SCULK_SHRIEKER_SHRIEK, 1.0f, 0.5f);
        StoryManager.later(28, () -> {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    final BlockPos pos = c.add(dx, 0, dz);
                    if (!inArena(pos)) continue;
                    final BlockState old = sw.getBlockState(pos);
                    if (old.isAir()) continue;
                    sw.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                    StoryManager.later(100, () -> sw.setBlockState(pos, old, Block.NOTIFY_LISTENERS));
                }
            }
        });
    }

    private void blink(ServerWorld sw, ServerPlayerEntity tg) {
        Vec3d back = tg.getRotationVec(1f).multiply(-1, 0, -1).normalize().multiply(3.0);
        Vec3d p = tg.getPos().add(back);
        this.getNavigation().stop();
        this.refreshPositionAndAngles(p.x, tg.getY(), p.z, tg.getYaw() + 180f, 0f);
        this.playSound(SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.5f, 0.3f);
        Net.send(tg, "GLITCH", "", 20);
    }

    private void summonEcho(ServerWorld sw, ServerPlayerEntity tg) {
        int n = sw.getEntitiesByType(ModEntities.ECHO, getBoundingBox().expand(60), e -> true).size();
        if (n >= 3) return;
        EchoEntity e = ModEntities.ECHO.create(sw);
        if (e == null) return;
        e.refreshPositionAndAngles(tg.getX() + (random.nextDouble() - 0.5) * 16, tg.getY(), tg.getZ() + (random.nextDouble() - 0.5) * 16, 0f, 0f);
        e.aggressive = true;
        sw.spawnEntity(e);
    }

    private void phaseChange(ServerWorld sw) {
        if (getServer() == null) return;
        for (ServerPlayerEntity sp : sw.getPlayers()) {
            if (sp.squaredDistanceTo(this) > 80 * 80) continue;
            Net.send(sp, "GLITCH", "", 80);
            if (phase == 2) {
                Net.send(sp, "FAKE_ERROR", "CRASH", 70);
                sp.sendMessage(Text.literal("§c<ERASER> เซฟนี้ไม่มีที่ว่างสำหรับคุณ"), false);
            } else if (phase == 3) {
                Net.send(sp, "OS_ERROR", "ERASER.exe - Not Responding|ERASER.exe is deleting: PLAYER_14\n\nProgress: 66%", 0);
                Net.send(sp, "SOUND", "SCREAM", 0);
                sp.sendMessage(Text.literal("§c<ERASER> ถึงเวลาลบแล้ว"), false);
            }
        }
        this.playSound(SoundEvents.ENTITY_WARDEN_ROAR, 3.0f, 0.5f);
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        if (this.getWorld() instanceof ServerWorld sw) {
            bar.clearPlayers();
            this.dropStack(new ItemStack(Items.NETHER_STAR));
            StoryManager.onBossDeath(sw, getX(), getY(), getZ());
        }
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        bar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        bar.removePlayer(player);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("ax", arenaX); nbt.putInt("ay", arenaY); nbt.putInt("az", arenaZ);
        nbt.putBoolean("aset", arenaSet);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        arenaX = nbt.getInt("ax"); arenaY = nbt.getInt("ay"); arenaZ = nbt.getInt("az");
        arenaSet = nbt.getBoolean("aset");
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_WARDEN_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.ENTITY_WARDEN_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_WARDEN_DEATH; }
    @Override public boolean canImmediatelyDespawn(double d) { return false; }
}
