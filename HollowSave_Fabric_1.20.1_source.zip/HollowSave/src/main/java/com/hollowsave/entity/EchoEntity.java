package com.hollowsave.entity;

import com.hollowsave.story.StoryManager;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * ECHO: the shadow of a deleted player, wearing YOUR skin.
 * It only moves when you are not looking at it. Look at it and it freezes; stare long enough and it vanishes.
 */
public class EchoEntity extends HostileEntity {
    public boolean aggressive = true;
    private int stare = 0;
    private int life = 0;

    public EchoEntity(EntityType<? extends EchoEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 0;
    }

    public static DefaultAttributeContainer.Builder attrs() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.36)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 64)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
    }

    private boolean seenBy(PlayerEntity p) {
        Vec3d look = p.getRotationVec(1.0f).normalize();
        Vec3d to = this.getEyePos().subtract(p.getEyePos()).normalize();
        return look.dotProduct(to) > 0.86 && p.canSee(this);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient) return;
        life++;
        if (life > (aggressive ? 2400 : 3600)) { vanish(); return; }

        PlayerEntity p = this.getWorld().getClosestPlayer(this, 64);
        if (p == null) return;
        boolean seen = seenBy(p);
        ServerWorld sw = (ServerWorld) this.getWorld();

        if (life % 10 == 0) sw.spawnParticles(ParticleTypes.SOUL, getX(), getY() + 1.0, getZ(), 2, 0.3, 0.6, 0.3, 0.01);

        if (seen) {
            stare++;
            this.getNavigation().stop();
            this.getLookControl().lookAt(p, 30f, 30f);
            if (stare > (aggressive ? 70 : 40)) { vanish(); return; }
        } else {
            if (stare > 0) stare--;
            if (aggressive) {
                this.getNavigation().startMovingTo(p, 1.25);
                if (this.squaredDistanceTo(p) < 3.2 && p instanceof ServerPlayerEntity sp) {
                    StoryManager.echoCaught(sp);
                    vanish();
                }
            } else {
                this.getNavigation().stop();
                this.getLookControl().lookAt(p, 30f, 30f);
            }
        }
    }

    private void vanish() {
        if (this.getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1.0, getZ(), 25, 0.3, 0.8, 0.3, 0.02);
        }
        this.playSound(SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.4f);
        this.discard();
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (this.getWorld().isClient) return false;
        if (source.isOf(net.minecraft.entity.damage.DamageTypes.OUT_OF_WORLD)) return super.damage(source, amount);
        vanish();
        return false;
    }

    @Override protected SoundEvent getAmbientSound() { return null; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return null; }
    @Override protected SoundEvent getDeathSound() { return null; }
    @Override public boolean canImmediatelyDespawn(double distanceSquared) { return false; }
}
