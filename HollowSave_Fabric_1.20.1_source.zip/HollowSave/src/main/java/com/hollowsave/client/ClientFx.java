package com.hollowsave.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Everything the server can ask the client to do: jumpscares, glitches, fake errors, outside-game effects. */
public final class ClientFx {
    private static final Random RND = new Random();
    private static final int SCARE_LEN = 60;

    private static int scareTicks = 0;
    private static String scareType = "FACE";
    private static int glitchTicks = 0;
    private static int titleReset = 0;

    private static final List<int[]> dummy = new ArrayList<>();
    private static final List<Object[]> LATER = new ArrayList<>();

    public static void later(int ticks, Runnable r) { LATER.add(new Object[]{ticks, r}); }

    public static void handle(MinecraftClient mc, String type, String arg, int n) {
        switch (type) {
            case "JUMPSCARE" -> startScare(mc, arg);
            case "GLITCH" -> glitchTicks = Math.max(glitchTicks, Math.max(n, 20));
            case "LAG" -> { glitchTicks = Math.max(glitchTicks, 20); ExternalFx.lag(n); }
            case "FAKE_LOADING" -> show(mc, new FakeScreen(FakeScreen.Kind.LOADING, n <= 0 ? 170 : n, "", ""));
            case "FAKE_ERROR" -> {
                if (arg.equals("CRASH")) show(mc, new FakeScreen(FakeScreen.Kind.CRASH, n <= 0 ? 230 : n, "", ""));
                else if (arg.equals("DISCONNECT")) show(mc, new FakeScreen(FakeScreen.Kind.DISCONNECT, 0, "", ""));
                else show(mc, new FakeScreen(FakeScreen.Kind.DIALOG, 0, "Minecraft", "Internal error 0x0000000D"));
            }
            case "OS_ERROR" -> ExternalFx.osError(arg);
            case "TITLE" -> {
                ExternalFx.setTitle(mc, arg);
                titleReset = arg.equals("RESET") ? 0 : (n > 0 ? n : 100);
            }
            case "ICON" -> ExternalFx.glitchIcon(mc);
            case "SOUND" -> ExternalAudio.play(arg);
            case "FILE" -> ExternalFx.writeFile(arg);
            case "CLEANUP" -> ExternalFx.cleanup(mc);
            default -> { }
        }
    }

    private static void show(MinecraftClient mc, FakeScreen s) {
        if (!(mc.currentScreen instanceof FakeScreen)) mc.setScreen(s);
    }

    private static void play(MinecraftClient mc, SoundEvent s, float pitch, float vol) {
        mc.getSoundManager().play(PositionedSoundInstance.master(s, pitch, vol));
    }

    public static void startScare(MinecraftClient mc, String type) {
        if (mc.currentScreen != null) mc.setScreen(null);
        scareType = type;
        scareTicks = SCARE_LEN;
        glitchTicks = 0;
        play(mc, SoundEvents.ENTITY_WARDEN_ROAR, 0.6f, 1.0f);
        play(mc, SoundEvents.ENTITY_GHAST_SCREAM, 0.5f, 1.0f);
        play(mc, SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE, 0.7f, 1.0f);
        ExternalAudio.play("SCREAM");
    }

    public static void tick(MinecraftClient mc) {
        if (scareTicks > 0) scareTicks--;
        if (glitchTicks > 0) glitchTicks--;
        if (titleReset > 0 && --titleReset == 0) ExternalFx.restoreTitle(mc);
        if (!LATER.isEmpty()) {
            for (Object[] o : new ArrayList<>(LATER)) {
                int left = (Integer) o[0] - 1;
                if (left <= 0) { LATER.remove(o); ((Runnable) o[1]).run(); } else o[0] = left;
            }
        }
    }

    // ------------------------------------------------------------------ HUD
    public static void renderHud(DrawContext c, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
        if (glitchTicks > 0) drawGlitch(c, mc, w, h);
        if (scareTicks > 0) {
            float prog = 1f - (scareTicks / (float) SCARE_LEN);
            c.fill(0, 0, w, h, 0xFF000000);
            if (scareType.equals("ECHO")) drawEcho(c, mc, w, h, prog);
            else drawFace(c, w, h, prog);
            noise(c, w, h, 90);
            if (scareTicks > SCARE_LEN - 3) c.fill(0, 0, w, h, 0xCCFFFFFF);
            c.getMatrices().push();
            c.getMatrices().translate(w / 2f, h * 0.86f, 0);
            c.getMatrices().scale(4f, 4f, 1f);
            String t = scareType.equals("ECHO") ? "คุณคือคนต่อไป" : "เจอแล้ว";
            c.drawCenteredTextWithShadow(mc.textRenderer, t, 0, 0, 0xFFFF1010);
            c.getMatrices().pop();
        }
    }

    private static void noise(DrawContext c, int w, int h, int n) {
        for (int i = 0; i < n; i++) {
            int x = RND.nextInt(w), y = RND.nextInt(h);
            c.fill(x, y, x + 1 + RND.nextInt(6), y + 1 + RND.nextInt(2), 0x66FFFFFF);
        }
    }

    private static void drawGlitch(DrawContext c, MinecraftClient mc, int w, int h) {
        int[] cols = {0x66FF0000, 0x6600FFFF, 0x66FFFFFF, 0xAA000000, 0x66FF00FF};
        int bars = 6 + RND.nextInt(10);
        for (int i = 0; i < bars; i++) {
            int y = RND.nextInt(h), bh = 2 + RND.nextInt(14);
            int x = RND.nextInt(w / 3);
            c.fill(x, y, w - RND.nextInt(w / 3), y + bh, cols[RND.nextInt(cols.length)]);
        }
        for (int y = 0; y < h; y += 4) c.fill(0, y, w, y + 1, 0x22000000);
        if (RND.nextInt(8) == 0) c.fill(0, 0, w, h, 0x33FFFFFF);
        if (RND.nextInt(6) == 0) {
            c.drawText(mc.textRenderer, "ERROR 0x0000000D", RND.nextInt(w - 80), RND.nextInt(h - 10), 0xFFFF2020, true);
        }
    }

    private static void drawFace(DrawContext c, int w, int h, float prog) {
        int cx = w / 2 + (int) ((RND.nextFloat() - 0.5f) * 14);
        int cy = h / 2 + (int) ((RND.nextFloat() - 0.5f) * 14);
        float zoom = 0.55f + 1.1f * Math.min(1f, prog * 5f);
        int fw = (int) (w * 0.46f * zoom), fh = (int) (h * 0.9f * zoom);
        c.fill(cx - fw / 2, cy - fh / 2, cx + fw / 2, cy + fh / 2, 0xFF0E0E0E);
        // eyes
        int ew = (int) (fw * 0.28f), eh = (int) (fh * 0.10f), ey = cy - (int) (fh * 0.15f);
        for (int side = -1; side <= 1; side += 2) {
            int ex = cx + side * (int) (fw * 0.24f);
            c.fill(ex - ew / 2 - 3, ey - eh / 2 - 6, ex + ew / 2 + 3, ey + eh / 2 + 6, 0xFF6A0303);
            c.fill(ex - ew / 2, ey - eh / 2, ex + ew / 2, ey + eh / 2, 0xFFF2F2F2);
            int px = ex + RND.nextInt(5) - 2, ps = Math.max(4, ew / 6);
            c.fill(px - ps / 2, ey - ps, px + ps / 2, ey + ps, 0xFF000000);
        }
        // mouth
        int mw = (int) (fw * 0.72f), mh = (int) (fh * (0.26f + 0.10f * (float) Math.sin(prog * 40)));
        int mx = cx - mw / 2, my = cy + (int) (fh * 0.12f);
        c.fill(mx, my, mx + mw, my + mh, 0xFF000000);
        int n = 14, tw = Math.max(2, mw / n);
        for (int i = 0; i < n; i++) {
            int th = (int) (mh * (0.22f + 0.07f * ((i * 7) % 4)));
            c.fill(mx + i * tw + 1, my, mx + (i + 1) * tw - 1, my + th, 0xFFE8E4D0);
            c.fill(mx + i * tw + 1, my + mh - th, mx + (i + 1) * tw - 1, my + mh, 0xFFE8E4D0);
        }
        // blood
        for (int i = 0; i < 9; i++) {
            int bx = mx + RND.nextInt(Math.max(1, mw));
            c.fill(bx, my + mh, bx + 3, my + mh + 10 + RND.nextInt(Math.max(1, fh / 6)), 0xFF8A0303);
        }
    }

    private static void drawEcho(DrawContext c, MinecraftClient mc, int w, int h, float prog) {
        Identifier tex = mc.player != null ? mc.player.getSkinTexture() : DefaultSkinHelper.getTexture();
        int size = (int) (Math.min(w, h) * (0.7f + 0.9f * Math.min(1f, prog * 5f)));
        int sx = (int) ((RND.nextFloat() - 0.5f) * 16), sy = (int) ((RND.nextFloat() - 0.5f) * 16);
        int x = w / 2 - size / 2 + sx, y = h / 2 - size / 2 + sy;
        c.drawTexture(tex, x, y, size, size, 8f, 8f, 8, 8, 64, 64);
        c.drawTexture(tex, x, y, size, size, 40f, 8f, 8, 8, 64, 64);
        float u = size / 8f;
        c.fill(x + (int) (0.9 * u), y + (int) (3.5 * u), x + (int) (3.1 * u), y + (int) (5.2 * u), 0xFF000000);
        c.fill(x + (int) (4.9 * u), y + (int) (3.5 * u), x + (int) (7.1 * u), y + (int) (5.2 * u), 0xFF000000);
        c.fill(x + (int) (1.7 * u), y + (int) (4.1 * u), x + (int) (2.3 * u), y + (int) (4.6 * u), 0xFFFF0000);
        c.fill(x + (int) (5.7 * u), y + (int) (4.1 * u), x + (int) (6.3 * u), y + (int) (4.6 * u), 0xFFFF0000);
        c.fill(x + (int) (2.2 * u), y + (int) (5.7 * u), x + (int) (5.8 * u), y + (int) (8.0 * u), 0xFF000000);
        c.fill(x, y, x + size, y + size, 0x55AA0000);
    }

    private ClientFx() {}
}
