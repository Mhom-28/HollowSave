package com.hollowsave.client;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.SharedConstants;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.system.MemoryUtil;

import javax.imageio.ImageIO;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Effects that reach outside the game: files on the desktop, window title and icon, OS-style error dialogs.
 * Everything is local and non-destructive. Nothing is sent anywhere. /hollow cleanup removes every created file.
 */
public final class ExternalFx {
    private static final Random RND = new Random();
    private static final AtomicBoolean DIALOG_OPEN = new AtomicBoolean(false);
    private static final String BOM = "\uFEFF";

    private static final String[] TITLES = {
            "Minecraft - ไม่ตอบสนอง",
            "Minecraft - HOLLOW_SAVE.dat (corrupted)",
            "อย่าหันหลัง",
            "13 กำลังมองคุณอยู่",
            "Minecraft - ERASER.exe is running",
            "Minecraft - {USER} (ถูกลบ 87%)",
            "ช่วยด้วย",
            "Minecraft - 0x0000000D",
    };

    // ---------------------------------------------------------------- title / icon / lag
    public static void setTitle(MinecraftClient mc, String arg) {
        try {
            if (arg.equals("RESET")) { restoreTitle(mc); return; }
            String t = arg.equals("RANDOM") ? TITLES[RND.nextInt(TITLES.length)] : arg;
            mc.getWindow().setTitle(t.replace("{USER}", mc.getSession().getUsername()));
        } catch (Throwable ignored) { }
    }

    public static void restoreTitle(MinecraftClient mc) {
        try {
            mc.getWindow().setTitle("Minecraft " + SharedConstants.getGameVersion().getName());
        } catch (Throwable ignored) { }
    }

    /** Freezes the render thread for a moment, like a real lag spike. */
    public static void lag(int ms) {
        try { Thread.sleep(Math.max(0, Math.min(ms, 2500))); } catch (InterruptedException ignored) { }
    }

    public static void glitchIcon(MinecraftClient mc) {
        int size = 32;
        ByteBuffer buf = MemoryUtil.memAlloc(size * size * 4);
        try {
            for (int y = 0; y < size; y++) {
                for (int x = 0; x < size; x++) {
                    int r = 8, g = 8, b = 8;
                    boolean eyeL = x >= 7 && x <= 12 && y >= 10 && y <= 15;
                    boolean eyeR = x >= 19 && x <= 24 && y >= 10 && y <= 15;
                    boolean pupil = (x == 10 || x == 22) && (y == 12 || y == 13);
                    boolean mouth = y >= 21 && y <= 27 && x >= 6 && x <= 25 && ((x + y) % 4 != 0);
                    if (eyeL || eyeR) { r = g = b = 240; }
                    if (pupil) { r = 200; g = 0; b = 0; }
                    if (mouth) { r = 200; g = 0; b = 0; }
                    if (x == 0 || y == 0 || x == size - 1 || y == size - 1) { r = 120; g = 0; b = 0; }
                    buf.put((byte) r).put((byte) g).put((byte) b).put((byte) 255);
                }
            }
            buf.flip();
            try (GLFWImage.Buffer imgs = GLFWImage.malloc(1)) {
                imgs.position(0).width(size).height(size).pixels(buf);
                GLFW.glfwSetWindowIcon(mc.getWindow().getHandle(), imgs);
            }
        } catch (Throwable ignored) {
        } finally {
            MemoryUtil.memFree(buf);
        }
    }

    // ---------------------------------------------------------------- OS dialog
    public static void osError(String arg) {
        String[] p = arg.split("\\|", 2);
        String title = p[0];
        String msg = p.length > 1 ? p[1] : "Unknown error";
        if (!DIALOG_OPEN.compareAndSet(false, true)) return;
        Thread t = new Thread(() -> {
            try {
                if (GraphicsEnvironment.isHeadless()) {
                    MinecraftClient.getInstance().execute(() -> {
                        if (!(MinecraftClient.getInstance().currentScreen instanceof FakeScreen))
                            MinecraftClient.getInstance().setScreen(new FakeScreen(FakeScreen.Kind.DIALOG, 0, title, msg));
                    });
                    return;
                }
                try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) { }
                JOptionPane pane = new JOptionPane(msg, JOptionPane.ERROR_MESSAGE);
                JDialog d = pane.createDialog(title);
                d.setAlwaysOnTop(true);
                d.setVisible(true);
            } catch (Throwable e) {
                MinecraftClient.getInstance().execute(() -> {
                    if (!(MinecraftClient.getInstance().currentScreen instanceof FakeScreen))
                        MinecraftClient.getInstance().setScreen(new FakeScreen(FakeScreen.Kind.DIALOG, 0, title, msg));
                });
            } finally {
                DIALOG_OPEN.set(false);
            }
        }, "HollowSave-Dialog");
        t.setDaemon(true);
        t.start();
    }

    // ---------------------------------------------------------------- files
    private static Path desktop() {
        Path home = Path.of(System.getProperty("user.home"));
        for (Path c : new Path[]{home.resolve("Desktop"), home.resolve("OneDrive").resolve("Desktop")}) {
            if (Files.isDirectory(c)) return c;
        }
        return home;
    }

    private static Path gameDir() { return FabricLoader.getInstance().getGameDir(); }

    private static void track(Path p) {
        try {
            Path list = gameDir().resolve("hollowsave_files.txt");
            Files.writeString(list, p.toAbsolutePath() + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Throwable ignored) { }
    }

    private static void writeText(Path p, String text) throws Exception {
        Files.createDirectories(p.getParent());
        Files.writeString(p, BOM + text, StandardCharsets.UTF_8);
        track(p);
    }

    public static void writeFile(String arg) {
        String[] a = arg.split("\\|", 2);
        String kind = a[0];
        String extra = a.length > 1 ? a[1] : "";
        String user = System.getProperty("user.name", "player");
        Thread t = new Thread(() -> {
            try {
                switch (kind) {
                    case "CLUE" -> {
                        String code = java.util.Base64.getEncoder().encodeToString("ARCHIVE13".getBytes(StandardCharsets.UTF_8));
                        Path f = desktop().resolve("READ_ME_13.txt");
                        writeText(f, "ถึงคุณ (" + user + "),\r\n\r\n"
                                + "ฉันไม่รู้ว่าคุณอ่านอยู่หรือเปล่า\r\n"
                                + "ฉันชื่อ 13 ฉันถูกขังอยู่ในเซฟที่คุณกำลังเล่น\r\n"
                                + "มันไม่ใช่เซฟของคุณ... มันเป็นของฉัน\r\n\r\n"
                                + "มีบางอย่างชื่อ THE ERASER กำลังลบทุกอย่าง\r\n"
                                + "มันลบคนก่อนหน้าฉันไปแล้ว 12 คน\r\n\r\n"
                                + "ฉันคุยในเกมได้ไม่นาน มันฟังอยู่\r\n"
                                + "ฉันเลยทิ้งรหัสนี้ไว้ ถอดมัน แล้วพิมพ์ในแชต:\r\n\r\n"
                                + "    /hollow decode <คำที่ถอดได้>\r\n\r\n"
                                + "รหัส (Base64):\r\n    " + code + "\r\n\r\n"
                                + "เงาที่เดินเข้ามา... ถ้าคุณมองมัน มันจะหยุด\r\n"
                                + "อย่าละสายตา\r\n\r\n- 13\r\n");
                        Thread.sleep(1500);
                        if (!GraphicsEnvironment.isHeadless() && Desktop.isDesktopSupported()) Desktop.getDesktop().open(f.toFile());
                    }
                    case "PHOTO" -> {
                        Path f = desktop().resolve("IMG_0013.png");
                        BufferedImage img = new BufferedImage(640, 480, BufferedImage.TYPE_INT_RGB);
                        for (int y = 0; y < 480; y++)
                            for (int x = 0; x < 640; x++) { int v = 8 + RND.nextInt(40); img.setRGB(x, y, (v << 16) | (v << 8) | v); }
                        Graphics2D g = img.createGraphics();
                        g.setColor(new Color(225, 225, 225));
                        g.fillOval(300, 130, 70, 80);
                        g.fillRect(285, 210, 100, 150);
                        g.fillRect(285, 360, 38, 90);
                        g.fillRect(347, 360, 38, 90);
                        g.setColor(new Color(220, 0, 0));
                        g.fillRect(316, 160, 10, 6);
                        g.fillRect(344, 160, 10, 6);
                        g.setFont(new Font("Monospaced", Font.BOLD, 20));
                        g.drawString("IMG_0013   " + LocalDateTime.now().withNano(0), 20, 460);
                        g.dispose();
                        Files.createDirectories(f.getParent());
                        ImageIO.write(img, "png", f.toFile());
                        track(f);
                    }
                    case "LOG" -> {
                        Path f = gameDir().resolve("crash-reports").resolve("crash-13-13-13_13.13.13-client.txt");
                        writeText(f, "---- Minecraft Crash Report ----\r\n// This is not a real crash.\r\n\r\n"
                                + "Description: Exception ticking world\r\n"
                                + "java.lang.IllegalStateException: Save 'HOLLOW_SAVE' has no owner\r\n"
                                + "    at com.hollowsave.Eraser.erase(Eraser.java:13)\r\n\r\n"
                                + "Player 13 was here.\r\nPlayer 14 is " + user + ".\r\n");
                    }
                    case "ARCHIVE" -> {
                        writeText(desktop().resolve("ARCHIVE_13.txt"),
                                "คุณถอดรหัสได้\r\n\r\n"
                                        + "เซฟนี้คือการทดลอง มันเก็บ \"ผู้เล่น\" ไว้เป็นข้อมูล\r\n"
                                        + "ผู้เล่นที่ล้มเหลวจะถูก THE ERASER ลบ\r\n"
                                        + "ฉันคือคนที่ 13 ฉันซ่อนตัวอยู่ในไฟล์ของคุณ\r\n\r\n"
                                        + "ศาลเจ้า (พิกัด X Y Z): " + extra + "\r\n\r\n"
                                        + "เดินเข้าไปใกล้ไฟวิญญาณ มันจะพาคุณไปหา THE ERASER\r\n"
                                        + "ฆ่ามัน แล้วฉันจะออกจากเซฟนี้ได้\r\n\r\n- 13\r\n");
                    }
                    case "FINAL" -> {
                        writeText(desktop().resolve("THANK_YOU_13.txt"),
                                "ขอบคุณ " + user + "\r\n\r\n"
                                        + "ฉันออกมาแล้ว\r\n"
                                        + "แต่เซฟนี้ต้องการผู้ดูแล\r\n"
                                        + "และคุณเป็นคนเดียวที่ยังอยู่ในนั้น\r\n\r\n"
                                        + "ตอนนี้คุณคือ 13\r\n"
                                        + "(พิมพ์ /hollow cleanup เพื่อลบไฟล์ทั้งหมดที่มอดสร้างไว้)\r\n");
                    }
                    default -> { }
                }
            } catch (Throwable ignored) { }
        }, "HollowSave-Files");
        t.setDaemon(true);
        t.start();
    }

    public static void cleanup(MinecraftClient mc) {
        try {
            Path list = gameDir().resolve("hollowsave_files.txt");
            if (Files.exists(list)) {
                List<String> lines = Files.readAllLines(list, StandardCharsets.UTF_8);
                for (String l : lines) {
                    try { Files.deleteIfExists(new File(l.trim()).toPath()); } catch (Throwable ignored) { }
                }
                Files.deleteIfExists(list);
            }
        } catch (Throwable ignored) { }
        restoreTitle(mc);
    }

    private ExternalFx() {}
}
