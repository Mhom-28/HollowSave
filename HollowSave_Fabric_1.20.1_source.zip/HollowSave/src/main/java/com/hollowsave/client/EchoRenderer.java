package com.hollowsave.client;

import com.hollowsave.entity.EchoEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.util.Identifier;

/** Renders ECHO as a see-through copy of the local player's own skin. */
public class EchoRenderer extends MobEntityRenderer<EchoEntity, PlayerEntityModel<EchoEntity>> {
    public EchoRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
    }

    @Override
    public Identifier getTexture(EchoEntity e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player != null ? mc.player.getSkinTexture() : DefaultSkinHelper.getTexture();
    }

    /** Returning false makes vanilla draw it ghost-translucent. */
    @Override
    protected boolean isVisible(EchoEntity e) {
        return false;
    }

    @Override
    protected boolean hasLabel(EchoEntity e) {
        return false;
    }
}
