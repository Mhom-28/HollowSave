package com.hollowsave.client;

import com.hollowsave.entity.EraserEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** A giant black wither-skeleton silhouette that periodically "glitches" its scale. */
public class EraserRenderer extends MobEntityRenderer<EraserEntity, BipedEntityModel<EraserEntity>> {
    private static final Identifier TEX = new Identifier("textures/entity/skeleton/wither_skeleton.png");

    public EraserRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.WITHER_SKELETON)), 1.4f);
    }

    @Override
    public Identifier getTexture(EraserEntity e) {
        return TEX;
    }

    @Override
    protected void scale(EraserEntity e, MatrixStack m, float amount) {
        if (e.age % 40 < 3) m.scale(3.7f, 2.6f, 3.0f);
        else m.scale(3.0f, 3.0f, 3.0f);
    }

    @Override
    protected boolean hasLabel(EraserEntity e) {
        return false;
    }
}
