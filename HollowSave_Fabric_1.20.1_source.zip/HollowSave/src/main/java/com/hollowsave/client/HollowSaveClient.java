package com.hollowsave.client;

import com.hollowsave.ModEntities;
import com.hollowsave.net.Net;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class HollowSaveClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.ECHO, EchoRenderer::new);
        EntityRendererRegistry.register(ModEntities.ERASER, EraserRenderer::new);

        ClientPlayNetworking.registerGlobalReceiver(Net.FX, (client, handler, buf, sender) -> {
            String type = buf.readString();
            String arg = buf.readString();
            int n = buf.readInt();
            client.execute(() -> ClientFx.handle(client, type, arg, n));
        });

        HudRenderCallback.EVENT.register(ClientFx::renderHud);
        ClientTickEvents.END_CLIENT_TICK.register(ClientFx::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ExternalFx.restoreTitle(client));
    }
}
