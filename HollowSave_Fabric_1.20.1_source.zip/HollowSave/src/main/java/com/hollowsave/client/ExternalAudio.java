package com.hollowsave.client;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.util.Random;

/** Plays procedurally generated horror audio through Java Sound, outside Minecraft's own sound engine. */
public final class ExternalAudio {
    private static final float RATE = 22050f;
    private static final float VOL = 0.5f;   // lower this if it is too loud
    private static final Random RND = new Random();

    public static void play(String kind) {
        Thread t = new Thread(() -> {
            try {
                byte[] pcm = gen(kind);
                AudioFormat f = new AudioFormat(RATE, 16, 1, true, false);
                Clip clip = AudioSystem.getClip();
                clip.open(f, pcm, 0, pcm.length);
                clip.start();
                Thread.sleep(pcm.length * 1000L / (int) (RATE * 2) + 400);
                clip.close();
            } catch (Throwable ignored) { }
        }, "HollowSave-Audio");
        t.setDaemon(true);
        t.start();
    }

    private static byte[] gen(String kind) {
        double secs = switch (kind) {
            case "SCREAM" -> 1.6;
            case "STATIC" -> 1.2;
            case "HEARTBEAT" -> 2.4;
            case "WHISPER" -> 3.0;
            default -> 4.0; // DRONE
        };
        int n = (int) (secs * RATE);
        byte[] out = new byte[n * 2];
        double phase = 0, lp = 0;
        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            double env = Math.min(1.0, Math.min(t / 0.05, (secs - t) / 0.3));
            double s;
            switch (kind) {
                case "SCREAM" -> {
                    double f = 700 + 900 * Math.sin(2 * Math.PI * 6 * t) + 500 * (t / secs);
                    phase += 2 * Math.PI * f / RATE;
                    s = (Math.sin(phase) + 0.5 * Math.sin(2 * phase) + 0.33 * Math.sin(3 * phase)) * 0.5 + (RND.nextDouble() - 0.5) * 0.6;
                    env = Math.min(env, 1.0);
                }
                case "STATIC" -> {
                    boolean gate = ((int) (t * 40)) % 3 != 0;
                    s = gate ? (RND.nextDouble() - 0.5) * 1.4 : 0;
                    env *= (1.0 - t / secs);
                }
                case "HEARTBEAT" -> {
                    double[] beats = {0.0, 0.28, 1.2, 1.48};
                    s = 0;
                    for (double b : beats) {
                        double dt = t - b;
                        if (dt >= 0 && dt < 0.25) s += Math.sin(2 * Math.PI * 50 * dt) * Math.exp(-dt * 18);
                    }
                    env = 1.0;
                }
                case "WHISPER" -> {
                    double burst = Math.max(0, Math.sin(2 * Math.PI * 0.9 * t)) * Math.max(0, Math.sin(2 * Math.PI * 2.3 * t + 1));
                    double nz = (RND.nextDouble() - 0.5) * 2;
                    lp += 0.35 * (nz - lp);
                    s = (nz - lp) * burst * 0.9;
                }
                default -> {
                    s = Math.sin(2 * Math.PI * 55 * t) * 0.5 + Math.sin(2 * Math.PI * 57.3 * t) * 0.5 + (RND.nextDouble() - 0.5) * 0.06;
                }
            }
            short v = (short) Math.max(-32767, Math.min(32767, s * env * VOL * 32767));
            out[2 * i] = (byte) (v & 0xFF);
            out[2 * i + 1] = (byte) ((v >> 8) & 0xFF);
        }
        return out;
    }

    private ExternalAudio() {}
}
