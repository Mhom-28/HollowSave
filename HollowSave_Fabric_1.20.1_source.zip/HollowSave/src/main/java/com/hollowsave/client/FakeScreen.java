package com.hollowsave.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Random;

/** Fake loading screen, fake crash, fake disconnect, fake OS-style dialog. The game keeps running behind it. */
public class FakeScreen extends Screen {
    public enum Kind { LOADING, CRASH, DISCONNECT, DIALOG }

    private static final String[] CRASH = {
            "---- Minecraft Crash Report ----",
            "// I let it happen. I'm sorry.",
            "",
            "Time: 13/13/13 13:13:13",
            "Description: Exception ticking world",
            "",
            "java.lang.IllegalStateException: Save 'HOLLOW_SAVE' has no owner",
            "    at com.hollowsave.Eraser.erase(Eraser.java:13)",
            "    at net.minecraft.server.world.ServerWorld.tick(ServerWorld.java:13)",
            "    at net.minecraft.server.MinecraftServer.tickWorlds(MinecraftServer.java:13)",
            "    at player.14.Existence.run(Existence.java:0)",
            "",
            "-- Affected level --",
            "Level name: HOLLOW_SAVE",
            "Players erased: 13 / 13",
            "",
            "ไม่ใช่บั๊ก",
            "ไม่เคยเป็นบั๊ก",
            "คุณคือคนต่อไป",
    };

    private final Kind kind;
    private final int length;
    private final String title;
    private final String msg;
    private int t = 0;
    private final Random rnd = new Random();

    public FakeScreen(Kind kind, int length, String title, String msg) {
        super(Text.literal("..."));
        this.kind = kind;
        this.length = length;
        this.title = title;
        this.msg = msg;
    }

    @Override
    protected void init() {
        if (kind == Kind.DIALOG) {
            addDrawableChild(ButtonWidget.builder(Text.literal("OK"), b -> close())
                    .dimensions(width / 2 - 40, height / 2 + 34, 80, 20).build());
        } else if (kind == Kind.DISCONNECT) {
            addDrawableChild(ButtonWidget.builder(Text.literal("กลับสู่หน้าจอหลัก"), b -> {
                close();
                ClientFx.later(40, () -> ClientFx.startScare(net.minecraft.client.MinecraftClient.getInstance(), "ECHO"));
            }).dimensions(width / 2 - 100, height / 2 + 40, 200, 20).build());
        }
    }

    @Override
    public void tick() {
        t++;
        if ((kind == Kind.LOADING || kind == Kind.CRASH) && t >= length) close();
    }

    @Override public boolean shouldPause() { return false; }
    @Override public boolean shouldCloseOnEsc() { return kind == Kind.DIALOG; }

    @Override
    public void render(DrawContext c, int mx, int my, float d) {
        switch (kind) {
            case LOADING -> loading(c);
            case CRASH -> crash(c);
            case DISCONNECT -> disconnect(c);
            default -> dialog(c);
        }
        super.render(c, mx, my, d);
    }

    private void loading(DrawContext c) {
        renderBackground(c);
        int pct = t < 60 ? (int) (t * 1.6f) : 96 + (t / 9) % 3;
        if (pct > 99) pct = 99;
        c.drawCenteredTextWithShadow(textRenderer, "Loading terrain...", width / 2, height / 2 - 30, 0xFFFFFF);
        int bw = 200, x = width / 2 - bw / 2, y = height / 2 - 10;
        c.fill(x - 2, y - 2, x + bw + 2, y + 12, 0xFF000000);
        c.fill(x, y, x + (int) (bw * pct / 100f), y + 10, t > 100 ? 0xFFAA0000 : 0xFF55FF55);
        c.drawCenteredTextWithShadow(textRenderer, pct + "%", width / 2, y + 18, 0xAAAAAA);
        if (t > 100) {
            c.drawCenteredTextWithShadow(textRenderer, "Chunk [13, 13] failed to load: NullPointerException", width / 2, y + 40, 0xFF5555);
            if (rnd.nextInt(3) == 0) c.drawCenteredTextWithShadow(textRenderer, "§kxxxxxxxxxxxxxxxxxxxxxx", width / 2, y + 54, 0xFF0000);
        }
    }

    private void crash(DrawContext c) {
        c.fill(0, 0, width, height, 0xFF000000);
        int shown = Math.min(CRASH.length, t / 3);
        for (int i = 0; i < shown; i++) {
            int col = i >= CRASH.length - 3 ? 0xFFFF2020 : 0xFFAAAAAA;
            c.drawText(textRenderer, CRASH[i], 10, 10 + i * 11, col, false);
        }
    }

    private void disconnect(DrawContext c) {
        renderBackgroundTexture(c);
        c.drawCenteredTextWithShadow(textRenderer, "Connection Lost", width / 2, height / 2 - 40, 0xFFFFFF);
        c.drawCenteredTextWithShadow(textRenderer, "Internal Exception: java.io.IOException: PLAYER_14 erased by remote host", width / 2, height / 2 - 20, 0xFF5555);
        c.drawCenteredTextWithShadow(textRenderer, "ไม่มีที่ให้กลับ", width / 2, height / 2, 0xAAAAAA);
    }

    private void dialog(DrawContext c) {
        renderBackground(c);
        int bw = 300, bh = 110, x = (width - bw) / 2, y = (height - bh) / 2;
        c.fill(x - 1, y - 1, x + bw + 1, y + bh + 1, 0xFF404040);
        c.fill(x, y, x + bw, y + 16, 0xFF1F3A93);
        c.drawText(textRenderer, title, x + 6, y + 4, 0xFFFFFFFF, false);
        c.fill(x, y + 16, x + bw, y + bh, 0xFFF0F0F0);
        c.fill(x + 12, y + 28, x + 38, y + 54, 0xFFCC0000);
        c.drawText(textRenderer, "X", x + 22, y + 37, 0xFFFFFFFF, false);
        List<OrderedText> lines = textRenderer.wrapLines(Text.literal(msg), bw - 70);
        for (int i = 0; i < lines.size() && i < 5; i++) c.drawText(textRenderer, lines.get(i), x + 50, y + 26 + i * 10, 0xFF000000, false);
    }
}
