package com.hollowsave.story;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;

public class StoryState extends PersistentState {
    public int stage = 0;
    public long ticks = 0;
    public long stageTick = 0;
    public long lastScare = 0;
    public boolean joinGag = false;
    public boolean sleepScare = false;
    public boolean arenaBuilt = false;
    public BlockPos shrine = null;
    public BlockPos arena = null;

    @Override
    public NbtCompound writeNbt(NbtCompound n) {
        n.putInt("stage", stage);
        n.putLong("ticks", ticks);
        n.putLong("stageTick", stageTick);
        n.putLong("lastScare", lastScare);
        n.putBoolean("joinGag", joinGag);
        n.putBoolean("sleepScare", sleepScare);
        n.putBoolean("arenaBuilt", arenaBuilt);
        if (shrine != null) n.putLong("shrine", shrine.asLong());
        if (arena != null) n.putLong("arena", arena.asLong());
        return n;
    }

    public static StoryState fromNbt(NbtCompound n) {
        StoryState s = new StoryState();
        s.stage = n.getInt("stage");
        s.ticks = n.getLong("ticks");
        s.stageTick = n.getLong("stageTick");
        s.lastScare = n.getLong("lastScare");
        s.joinGag = n.getBoolean("joinGag");
        s.sleepScare = n.getBoolean("sleepScare");
        s.arenaBuilt = n.getBoolean("arenaBuilt");
        if (n.contains("shrine")) s.shrine = BlockPos.fromLong(n.getLong("shrine"));
        if (n.contains("arena")) s.arena = BlockPos.fromLong(n.getLong("arena"));
        return s;
    }

    public static StoryState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager()
                .getOrCreate(StoryState::fromNbt, StoryState::new, "hollowsave_story");
    }
}
