package com.hollowsave.story;

import com.hollowsave.net.Net;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public final class HollowCommand {

    public static void register(CommandDispatcher<ServerCommandSource> d, CommandRegistryAccess reg,
                                CommandManager.RegistrationEnvironment env) {
        d.register(CommandManager.literal("hollow")
                .then(CommandManager.literal("decode")
                        .then(CommandManager.argument("code", StringArgumentType.greedyString())
                                .executes(HollowCommand::decode)))
                .then(CommandManager.literal("hint").executes(HollowCommand::hint))
                .then(CommandManager.literal("cleanup").executes(c -> {
                    for (ServerPlayerEntity p : c.getSource().getServer().getPlayerManager().getPlayerList()) Net.send(p, "CLEANUP");
                    c.getSource().sendFeedback(() -> Text.literal("§7[HOLLOW SAVE] files removed. 13 will remember."), false);
                    return 1;
                }))
                .then(CommandManager.literal("stage").requires(s -> s.hasPermissionLevel(2))
                        .then(CommandManager.argument("n", IntegerArgumentType.integer(0, 5)).executes(c -> {
                            MinecraftServer srv = c.getSource().getServer();
                            StoryState s = StoryState.get(srv);
                            int n = IntegerArgumentType.getInteger(c, "n");
                            if (n <= 3) StoryManager.enterStage(srv, s, n);
                            else { s.stage = n; s.markDirty(); }
                            c.getSource().sendFeedback(() -> Text.literal("stage = " + n), false);
                            return 1;
                        })))
                .then(CommandManager.literal("scare").requires(s -> s.hasPermissionLevel(2))
                        .then(CommandManager.argument("type", StringArgumentType.word()).executes(c -> {
                            StoryManager.scare(c.getSource().getServer(), StringArgumentType.getString(c, "type").toUpperCase());
                            return 1;
                        })))
                .then(CommandManager.literal("fx").requires(s -> s.hasPermissionLevel(2))
                        .then(CommandManager.argument("type", StringArgumentType.word())
                                .executes(c -> fx(c, ""))
                                .then(CommandManager.argument("arg", StringArgumentType.greedyString())
                                        .executes(c -> fx(c, StringArgumentType.getString(c, "arg"))))))
                .then(CommandManager.literal("reset").requires(s -> s.hasPermissionLevel(2)).executes(c -> {
                    StoryState s = StoryState.get(c.getSource().getServer());
                    s.stage = 0; s.ticks = 0; s.stageTick = 0; s.lastScare = 0;
                    s.joinGag = false; s.sleepScare = false; s.markDirty();
                    c.getSource().sendFeedback(() -> Text.literal("story reset"), false);
                    return 1;
                })));
    }

    private static int fx(CommandContext<ServerCommandSource> c, String arg) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
        Net.send(p, StringArgumentType.getString(c, "type").toUpperCase(), arg, 120);
        return 1;
    }

    private static int decode(CommandContext<ServerCommandSource> c) {
        MinecraftServer srv = c.getSource().getServer();
        StoryState s = StoryState.get(srv);
        String in = StringArgumentType.getString(c, "code").trim().replace(" ", "");
        if (s.stage < 2) {
            StoryManager.chat(srv, "<13> ...ยังไม่ถึงเวลา");
        } else if (s.stage == 2 && in.equalsIgnoreCase(StoryManager.CODE)) {
            StoryManager.enterStage(srv, s, 3);
        } else if (s.stage == 2) {
            StoryManager.chat(srv, "<13> ไม่ใช่... อ่านไฟล์อีกที");
            StoryManager.fx(srv, "GLITCH", "", 40);
        } else {
            StoryManager.chat(srv, "<13> คุณถอดไปแล้ว ไปที่ศาลเจ้าเถอะ");
        }
        return 1;
    }

    private static int hint(CommandContext<ServerCommandSource> c) {
        StoryState s = StoryState.get(c.getSource().getServer());
        String t = switch (s.stage) {
            case 0, 1 -> "13 ทิ้งไฟล์ไว้นอกเกม ดูที่เดสก์ท็อป และอย่าละสายตาจากเงาที่เดินเข้ามา";
            case 2 -> "ไฟล์ READ_ME_13.txt มีรหัส Base64 ถอดออก แล้วพิมพ์ /hollow decode <คำที่ได้>";
            case 3 -> "ไปที่ศาลเจ้า (ดูพิกัดในแชตหรือไฟล์ ARCHIVE_13.txt)";
            case 4 -> "หลบการลบพื้น และอย่าตกลงไป ผู้ลบอ่อนแอลงเมื่อเลือดลด";
            default -> "จบแล้ว... หรือเปล่า";
        };
        c.getSource().sendFeedback(() -> Text.literal("§8[hint] §7" + t), false);
        return 1;
    }

    private HollowCommand() {}
}
