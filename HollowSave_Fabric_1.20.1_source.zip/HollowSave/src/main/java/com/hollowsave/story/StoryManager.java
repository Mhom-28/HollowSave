package com.hollowsave.story;

import com.hollowsave.HollowSave;
import com.hollowsave.ModEntities;
import com.hollowsave.entity.EchoEntity;
import com.hollowsave.entity.EraserEntity;
import com.hollowsave.net.Net;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.List;

/**
 * HOLLOW SAVE story engine.
 * Stage 0 calm | 1 static | 2 corruption | 3 archive (find the shrine) | 4 boss | 5 ending
 */
public final class StoryManager {
    // ---- tuning ---------------------------------------------------------
    public static final String CODE = "ARCHIVE13";
    public static final boolean WORLD_DAMAGE = true;     // false = no block corruption
    public static final int T_STAGE1 = 20 * 60 * 5;      // 5 min of play
    public static final int T_STAGE2 = 20 * 60 * 15;     // 15 min of play
    public static final int SCARE_GAP = 20 * 60 * 5;     // min gap between random jumpscares
    public static final int ARENA_Y = 200;
    public static final int ARENA_R = 20;

    private static final String[] SCARE_TYPES = {"FACE", "ECHO"};

    private static final String[] CHAT = {
            "<13> ฉันเห็นคุณนะ",
            "<13> อย่าขุดลงไปลึกกว่านี้",
            "<13> มีบางอย่างยืนอยู่ข้างหลังคุณ",
            "<13> ได้โปรด อ่านไฟล์ที่ฉันทิ้งไว้",
            "<13> มันกำลังลบเซฟนี้ ทีละนิด",
            "<§k13§r> §kxxxxxxxxxxxxxxxx",
            "§c[ERROR] chunk (13,13) is not supposed to exist",
            "§7[Server] Saving world... 99%... 99%... 99%...",
    };

    private static final List<Task> TASKS = new ArrayList<>();

    private static final class Task {
        int left;
        final Runnable r;
        Task(int l, Runnable r) { this.left = l; this.r = r; }
    }

    public static void later(int ticks, Runnable r) { TASKS.add(new Task(ticks, r)); }

    // ---- init -------------------------------------------------------------
    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(StoryManager::tick);
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> TASKS.clear());
        CommandRegistrationCallback.EVENT.register(HollowCommand::register);
        EntitySleepEvents.START_SLEEPING.register((entity, pos) -> {
            if (entity instanceof ServerPlayerEntity sp && sp.getServer() != null) {
                MinecraftServer srv = sp.getServer();
                StoryState s = StoryState.get(srv);
                if (s.stage >= 2 && s.stage < 5 && !s.sleepScare) {
                    s.sleepScare = true;
                    s.markDirty();
                    later(100, () -> scare(srv, "ECHO"));
                }
            }
        });
    }

    // ---- helpers ----------------------------------------------------------
    public static void chat(MinecraftServer server, String msg) {
        server.getPlayerManager().broadcast(Text.literal(msg), false);
    }

    public static void fx(MinecraftServer server, String type, String arg, int n) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) Net.send(p, type, arg, n);
    }

    private static String pick(Random r, String[] a) { return a[r.nextInt(a.length)]; }

    public static void scare(MinecraftServer server, String type) {
        StoryState s = StoryState.get(server);
        s.lastScare = s.ticks;
        s.markDirty();
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            Net.send(p, "JUMPSCARE", type, 0);
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 0));
        }
    }

    public static void echoCaught(ServerPlayerEntity p) {
        MinecraftServer srv = p.getServer();
        if (srv != null) {
            StoryState s = StoryState.get(srv);
            s.lastScare = s.ticks;
        }
        Net.send(p, "JUMPSCARE", "ECHO", 0);
        Net.send(p, "SOUND", "SCREAM", 0);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 60, 0));
        p.damage(p.getWorld().getDamageSources().generic(), 4.0f);
    }

    private static void ambient(ServerPlayerEntity p) {
        SoundEvent[] pool = {SoundEvents.BLOCK_SCULK_SHRIEKER_SHRIEK, SoundEvents.ENTITY_WARDEN_HEARTBEAT,
                SoundEvents.ENTITY_ENDERMAN_STARE, SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE,
                SoundEvents.ENTITY_ZOMBIE_VILLAGER_CURE, SoundEvents.ENTITY_WARDEN_AMBIENT};
        p.playSound(pool[p.getRandom().nextInt(pool.length)], 0.8f, 0.5f + p.getRandom().nextFloat() * 0.4f);
    }

    private static int echoCount(ServerWorld w, ServerPlayerEntity p) {
        return w.getEntitiesByType(ModEntities.ECHO, p.getBoundingBox().expand(80), e -> true).size();
    }

    private static void spawnEcho(ServerWorld w, ServerPlayerEntity p, boolean aggressive, int dist) {
        double ang = w.random.nextDouble() * Math.PI * 2;
        int x = (int) (p.getX() + Math.cos(ang) * dist);
        int z = (int) (p.getZ() + Math.sin(ang) * dist);
        if (!w.isChunkLoaded(new BlockPos(x, 64, z))) return;
        int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        EchoEntity e = ModEntities.ECHO.create(w);
        if (e == null) return;
        e.refreshPositionAndAngles(x + 0.5, y, z + 0.5, w.random.nextFloat() * 360f, 0f);
        e.aggressive = aggressive;
        w.spawnEntity(e);
    }

    private static void set(ServerWorld w, int x, int y, int z, BlockState st) {
        w.setBlockState(new BlockPos(x, y, z), st, Block.NOTIFY_LISTENERS);
    }

    // ---- main tick ----------------------------------------------------------
    private static void tick(MinecraftServer server) {
        if (!TASKS.isEmpty()) {
            for (Task t : new ArrayList<>(TASKS)) {
                if (--t.left <= 0) {
                    TASKS.remove(t);
                    try { t.r.run(); } catch (Throwable e) { HollowSave.LOG.error("task failed", e); }
                }
            }
        }
        List<ServerPlayerEntity> ps = server.getPlayerManager().getPlayerList();
        if (ps.isEmpty()) return;
        ServerWorld ow = server.getOverworld();
        StoryState s = StoryState.get(server);
        s.ticks++;
        if (s.ticks % 600 == 0) s.markDirty();

        if (s.stage == 0 && s.ticks >= T_STAGE1) enterStage(server, s, 1);
        else if (s.stage == 1 && s.ticks >= T_STAGE2) enterStage(server, s, 2);

        if (s.ticks % 20 == 0) secondly(server, ow, s, ps);
        if (s.ticks % 5 == 0) watch(server, ow, s, ps);
    }

    private static void secondly(MinecraftServer server, ServerWorld ow, StoryState s, List<ServerPlayerEntity> ps) {
        Random r = ow.random;
        ServerPlayerEntity p = ps.get(r.nextInt(ps.size()));
        if (p.getWorld() != ow && s.stage != 4) return;
        switch (s.stage) {
            case 0 -> {
                if (r.nextInt(120) == 0) ambient(p);
                if (!s.joinGag && s.ticks > 20 * 150) {
                    s.joinGag = true;
                    s.markDirty();
                    chat(server, "§e13 joined the game");
                    later(100, () -> chat(server, "§e13 left the game"));
                }
            }
            case 1 -> {
                if (r.nextInt(70) == 0) Net.send(p, "TITLE", "RANDOM", 120);
                if (r.nextInt(110) == 0) Net.send(p, "GLITCH", "", 30);
                if (r.nextInt(150) == 0) chat(server, pick(r, CHAT));
                if (r.nextInt(200) == 0) ambient(p);
                if (r.nextInt(260) == 0 && echoCount(ow, p) == 0) spawnEcho(ow, p, false, 26);
                if (r.nextInt(500) == 0) Net.send(p, "FAKE_LOADING", "", 170);
                if (r.nextInt(480) == 0) Net.send(p, "SOUND", "WHISPER", 0);
            }
            case 2 -> {
                if (ow.getTimeOfDay() % 24000L < 13000L) {
                    ow.setTimeOfDay((ow.getTimeOfDay() / 24000L) * 24000L + 14000L);
                }
                if (!ow.isThundering()) ow.setWeather(0, 6000, true, true);
                if (WORLD_DAMAGE && s.ticks % 40 == 0) {
                    for (ServerPlayerEntity q : ps) {
                        if (q.getWorld() == ow) corrupt(ow, q.getBlockPos(), 22, 18);
                    }
                }
                if (r.nextInt(60) == 0 && echoCount(ow, p) == 0) spawnEcho(ow, p, true, 22);
                if (r.nextInt(40) == 0) Net.send(p, "GLITCH", "", 40);
                if (r.nextInt(80) == 0) Net.send(p, "TITLE", "RANDOM", 100);
                if (r.nextInt(100) == 0) Net.send(p, "SOUND", "DRONE", 0);
                if (r.nextInt(120) == 0) chat(server, pick(r, CHAT));
                if (r.nextInt(160) == 0) ambient(p);
                if (r.nextInt(600) == 0) Net.send(p, "FAKE_LOADING", "", 170);
                if (r.nextInt(700) == 0) Net.send(p, "LAG", "", 900);
                if (r.nextInt(1100) == 0) {
                    Net.send(p, "OS_ERROR", "javaw.exe - Application Error|The instruction at 0x00000013 referenced memory at 0x00000000.\nThe memory could not be read.\n\nClick OK to terminate the program.", 0);
                }
                if (r.nextInt(2400) == 0) Net.send(p, "FAKE_ERROR", "DISCONNECT", 0);
                if (s.ticks - s.lastScare > SCARE_GAP && s.ticks - s.stageTick > 20 * 70 && r.nextInt(300) == 0) {
                    scare(server, pick(r, SCARE_TYPES));
                }
            }
            case 3 -> {
                if (r.nextInt(90) == 0) ambient(p);
                if (r.nextInt(240) == 0) Net.send(p, "GLITCH", "", 20);
                if (r.nextInt(400) == 0) Net.send(p, "TITLE", "RANDOM", 100);
                if (r.nextInt(500) == 0 && s.shrine != null) {
                    chat(server, "<13> ไปที่ศาลเจ้า... X " + s.shrine.getX() + " Y " + s.shrine.getY() + " Z " + s.shrine.getZ());
                }
            }
            default -> { }
        }
    }

    /** Runs every 5 ticks: shrine trigger, arena rescue. */
    private static void watch(MinecraftServer server, ServerWorld ow, StoryState s, List<ServerPlayerEntity> ps) {
        if ((s.stage == 3 || s.stage == 4) && s.shrine != null) {
            ow.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, s.shrine.getX() + 0.5, s.shrine.getY() + 2, s.shrine.getZ() + 0.5, 3, 0.3, 1.0, 0.3, 0.01);
            for (ServerPlayerEntity p : ps) {
                if (p.getWorld() == ow && p.squaredDistanceTo(s.shrine.getX() + 0.5, s.shrine.getY(), s.shrine.getZ() + 0.5) < 16) {
                    enterArena(server, s, p);
                    break;
                }
            }
        }
        if (s.stage == 4 && s.arena != null) {
            BlockPos c = s.arena;
            for (ServerPlayerEntity p : ps) {
                if (p.getWorld() == ow && Math.abs(p.getX() - c.getX()) < 60 && Math.abs(p.getZ() - c.getZ()) < 60 && p.getY() < c.getY() - 8) {
                    p.teleport(ow, c.getX() + 0.5, c.getY() + 1, c.getZ() - 10 + 0.5, 0f, 0f);
                    p.damage(ow.getDamageSources().generic(), 2f);
                    Net.send(p, "GLITCH", "", 30);
                    p.sendMessage(Text.literal("§c[ERROR] player position invalid. rolling back..."), false);
                }
            }
        }
    }

    // ---- stages ---------------------------------------------------------------
    public static void enterStage(MinecraftServer server, StoryState s, int n) {
        s.stage = n;
        s.stageTick = s.ticks;
        s.markDirty();
        ServerWorld ow = server.getOverworld();
        HollowSave.LOG.info("[HOLLOW SAVE] stage -> {}", n);
        switch (n) {
            case 1 -> {
                chat(server, "§e13 joined the game");
                later(60, () -> chat(server, "<13> ...ได้ยินฉันไหม"));
                later(160, () -> {
                    chat(server, "<13> ฉันทิ้งอะไรไว้ให้คุณ ดูที่เดสก์ท็อปของคุณ");
                    fx(server, "FILE", "CLUE", 0);
                    fx(server, "FILE", "LOG", 0);
                });
                later(300, () -> chat(server, "§e13 left the game"));
            }
            case 2 -> {
                fx(server, "GLITCH", "", 100);
                fx(server, "TITLE", "SAVE CORRUPTED", 200);
                fx(server, "FILE", "PHOTO", 0);
                fx(server, "ICON", "GLITCH", 0);
                fx(server, "SOUND", "STATIC", 0);
                chat(server, "§c[WARNING] HOLLOW_SAVE.dat checksum mismatch");
                later(120, () -> chat(server, "§c[WARNING] 12 / 13 slots erased"));
                later(240, () -> fx(server, "OS_ERROR", "Minecraft - Fatal Error|HOLLOW_SAVE.dat is corrupted.\nSome of your files may be erased.\n\nError code: 0x0000000D", 0));
                later(20 * 40, () -> scare(server, "FACE"));
            }
            case 3 -> {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    for (EchoEntity e : ow.getEntitiesByType(ModEntities.ECHO, p.getBoundingBox().expand(120), x -> true)) e.discard();
                }
                BlockPos sh = buildShrine(server, ow);
                s.shrine = sh;
                s.markDirty();
                fx(server, "GLITCH", "", 60);
                chat(server, "<13> ...คุณถอดรหัสได้");
                later(80, () -> chat(server, "<13> ขอบคุณ มันฟังไม่ได้ในช่วงนี้"));
                later(180, () -> chat(server, "<13> ที่ศาลเจ้า X " + sh.getX() + " Y " + sh.getY() + " Z " + sh.getZ()));
                later(260, () -> chat(server, "<13> เดินเข้าไปใกล้ๆ มัน ผู้ลบ (THE ERASER) รอคุณอยู่ข้างใน"));
                fx(server, "FILE", "ARCHIVE|" + sh.getX() + " " + sh.getY() + " " + sh.getZ(), 0);
            }
            default -> { }
        }
    }

    private static BlockPos buildShrine(MinecraftServer server, ServerWorld ow) {
        ServerPlayerEntity p = server.getPlayerManager().getPlayerList().get(0);
        double ang = ow.random.nextDouble() * Math.PI * 2;
        int sx = (int) (p.getX() + Math.cos(ang) * 45);
        int sz = (int) (p.getZ() + Math.sin(ang) * 45);
        ow.getChunk(sx >> 4, sz >> 4);
        int sy = ow.getTopY(Heightmap.Type.WORLD_SURFACE, sx, sz);
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                for (int dy = 0; dy <= 5; dy++) set(ow, sx + dx, sy + dy, sz + dz, Blocks.AIR.getDefaultState());
                set(ow, sx + dx, sy - 1, sz + dz,
                        (ow.random.nextInt(4) == 0 ? Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS : Blocks.POLISHED_BLACKSTONE_BRICKS).getDefaultState());
            }
        }
        for (int cx = -2; cx <= 2; cx += 4) {
            for (int cz = -2; cz <= 2; cz += 4) {
                for (int dy = 0; dy < 4; dy++) set(ow, sx + cx, sy + dy, sz + cz, Blocks.POLISHED_BLACKSTONE_BRICK_WALL.getDefaultState());
                set(ow, sx + cx, sy + 4, sz + cz, Blocks.SOUL_LANTERN.getDefaultState());
            }
        }
        set(ow, sx, sy - 1, sz, Blocks.SOUL_SOIL.getDefaultState());
        set(ow, sx, sy, sz, Blocks.SOUL_FIRE.getDefaultState());
        return new BlockPos(sx, sy, sz);
    }

    // ---- arena / boss ------------------------------------------------------------
    private static void enterArena(MinecraftServer server, StoryState s, ServerPlayerEntity who) {
        ServerWorld ow = server.getOverworld();
        if (s.arena == null) {
            s.arena = new BlockPos(s.shrine.getX() + 300, ARENA_Y, s.shrine.getZ() + 300);
            s.markDirty();
        }
        BlockPos c = s.arena;
        if (!s.arenaBuilt) {
            buildArena(ow, c);
            s.arenaBuilt = true;
            s.markDirty();
        }
        boolean first = s.stage == 3;
        s.stage = 4;
        s.stageTick = s.ticks;
        s.markDirty();

        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (p == who || p.squaredDistanceTo(who) < 400) {
                p.teleport(ow, c.getX() + 0.5, c.getY() + 1, c.getZ() - 14 + 0.5, 0f, 0f);
                Net.send(p, "GLITCH", "", 80);
                Net.send(p, "TITLE", "THE ERASER", 400);
                Net.send(p, "SOUND", "DRONE", 0);
            }
        }
        List<EraserEntity> found = ow.getEntitiesByType(ModEntities.ERASER, new Box(c).expand(60), e -> true);
        if (found.isEmpty()) {
            EraserEntity boss = ModEntities.ERASER.create(ow);
            if (boss != null) {
                boss.refreshPositionAndAngles(c.getX() + 0.5, c.getY() + 1, c.getZ() + 10 + 0.5, 180f, 0f);
                boss.setArena(c.getX(), c.getY(), c.getZ());
                ow.spawnEntity(boss);
            }
        }
        if (first) {
            later(40, () -> chat(server, "§c<ERASER> เจอแล้ว ผู้เล่นคนที่ 14"));
            later(120, () -> fx(server, "OS_ERROR", "ERASER.exe - Application Error|ERASER.exe is erasing your save file.\n\nClick OK to cancel.", 0));
        }
    }

    private static void buildArena(ServerWorld ow, BlockPos c) {
        int R = ARENA_R;
        Random r = ow.random;
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                int d2 = dx * dx + dz * dz;
                if (d2 > R * R) continue;
                int x = c.getX() + dx, z = c.getZ() + dz;
                ow.getChunk(x >> 4, z >> 4);
                for (int dy = 1; dy <= 16; dy++) set(ow, x, c.getY() + dy, z, Blocks.AIR.getDefaultState());
                Block b = r.nextInt(6) == 0 ? Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS
                        : (r.nextInt(3) == 0 ? Blocks.BLACKSTONE : Blocks.POLISHED_BLACKSTONE_BRICKS);
                set(ow, x, c.getY(), z, b.getDefaultState());
                set(ow, x, c.getY() - 1, z, Blocks.BLACKSTONE.getDefaultState());
                if (d2 > (R - 1) * (R - 1) && (dx + dz) % 3 == 0) set(ow, x, c.getY() + 1, z, Blocks.CRYING_OBSIDIAN.getDefaultState());
            }
        }
        for (int px = -12; px <= 12; px += 24) {
            for (int pz = -12; pz <= 12; pz += 24) {
                for (int dy = 1; dy <= 7; dy++) set(ow, c.getX() + px, c.getY() + dy, c.getZ() + pz, Blocks.POLISHED_BLACKSTONE_BRICKS.getDefaultState());
                set(ow, c.getX() + px, c.getY() + 8, c.getZ() + pz, Blocks.SOUL_LANTERN.getDefaultState());
            }
        }
    }

    public static void onBossDeath(ServerWorld w, double x, double y, double z) {
        MinecraftServer server = w.getServer();
        StoryState s = StoryState.get(server);
        s.stage = 5;
        s.stageTick = s.ticks;
        s.markDirty();
        fx(server, "GLITCH", "", 120);
        fx(server, "SOUND", "STATIC", 0);
        chat(server, "§c<ERASER> ...ลบ...ไม่ได้...");
        later(100, () -> {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (s.shrine != null) p.teleport(w, s.shrine.getX() + 0.5, s.shrine.getY() + 1, s.shrine.getZ() + 3.5, 0f, 0f);
            }
            w.setWeather(6000, 0, false, false);
            w.setTimeOfDay(((w.getTimeOfDay() / 24000L) + 1) * 24000L + 100L);
            chat(server, "<13> ...เงียบจัง");
        });
        later(260, () -> {
            chat(server, "<13> ฉันออกมาได้แล้ว ขอบคุณ");
            fx(server, "FILE", "FINAL", 0);
            fx(server, "TITLE", "RESET", 0);
        });
        later(20 * 30, () -> chat(server, "§e13 left the game"));
        later(20 * 50, () -> fx(server, "FAKE_ERROR", "CRASH", 260));
        later(20 * 65, () -> scare(server, "ECHO"));
        later(20 * 70, () -> {
            chat(server, "§7เซฟนี้ต้องมีผู้ดูแลคนใหม่");
            fx(server, "TITLE", "คุณคือ 13 แล้ว", 600);
        });
    }

    // ---- world corruption -----------------------------------------------------------
    private static Block pick(Random r, Block... a) { return a[r.nextInt(a.length)]; }

    private static void corrupt(ServerWorld w, BlockPos c, int r, int tries) {
        Random rnd = w.random;
        for (int i = 0; i < tries; i++) {
            int x = c.getX() + rnd.nextInt(2 * r + 1) - r;
            int z = c.getZ() + rnd.nextInt(2 * r + 1) - r;
            if (!w.isChunkLoaded(new BlockPos(x, 64, z))) continue;
            int y = w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) - 1;
            BlockPos pos = new BlockPos(x, y, z);
            BlockState st = w.getBlockState(pos);
            if (w.getBlockEntity(pos) != null) continue;
            Block to = null;
            if (st.isOf(Blocks.GRASS_BLOCK) || st.isOf(Blocks.DIRT) || st.isOf(Blocks.PODZOL)) {
                to = pick(rnd, Blocks.SOUL_SOIL, Blocks.COARSE_DIRT, Blocks.BLACKSTONE, Blocks.SCULK);
            } else if (st.isOf(Blocks.STONE) || st.isOf(Blocks.COBBLESTONE) || st.isOf(Blocks.ANDESITE)) {
                to = pick(rnd, Blocks.BLACKSTONE, Blocks.DEEPSLATE);
            } else if (st.isOf(Blocks.SAND)) {
                to = Blocks.SOUL_SAND;
            } else if (st.isIn(BlockTags.LEAVES)) {
                to = Blocks.AIR;
            } else if (st.isIn(BlockTags.FLOWERS)) {
                to = Blocks.DEAD_BUSH;
            } else if (st.isIn(BlockTags.LOGS)) {
                to = Blocks.BASALT;
            }
            if (to != null) w.setBlockState(pos, to.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
    }

    private StoryManager() {}
}
